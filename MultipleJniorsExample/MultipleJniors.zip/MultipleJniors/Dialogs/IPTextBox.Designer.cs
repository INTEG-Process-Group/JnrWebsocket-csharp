/// <md5Hash>760773347df63f8ddf0830cf29e769f9</md5Hash>
/// <date>6/13/2011 9:30:34 AM</date>
/// <version>1</version>


    partial class IPTextBox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOctet1 = new System.Windows.Forms.TextBox();
            this.txtOctet2 = new System.Windows.Forms.TextBox();
            this.txtOctet3 = new System.Windows.Forms.TextBox();
            this.txtOctet4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(131, 20);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(26, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = ".";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(59, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = ".";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(92, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = ".";
            // 
            // txtOctet1
            // 
            this.txtOctet1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOctet1.Location = new System.Drawing.Point(1, 3);
            this.txtOctet1.Name = "txtOctet1";
            this.txtOctet1.Size = new System.Drawing.Size(27, 13);
            this.txtOctet1.TabIndex = 8;
            this.txtOctet1.Text = "0";
            this.txtOctet1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtOctet1.Leave += new System.EventHandler(this.txtOctet_Leave);
            this.txtOctet1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOctet_KeyPress);
            this.txtOctet1.Enter += new System.EventHandler(this.txtOctet_Enter);
            this.txtOctet1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.txtOctet_MouseUp);
            // 
            // txtOctet2
            // 
            this.txtOctet2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOctet2.Location = new System.Drawing.Point(34, 3);
            this.txtOctet2.Name = "txtOctet2";
            this.txtOctet2.Size = new System.Drawing.Size(27, 13);
            this.txtOctet2.TabIndex = 9;
            this.txtOctet2.Text = "0";
            this.txtOctet2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtOctet2.Leave += new System.EventHandler(this.txtOctet_Leave);
            this.txtOctet2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOctet_KeyPress);
            this.txtOctet2.Enter += new System.EventHandler(this.txtOctet_Enter);
            this.txtOctet2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.txtOctet_MouseUp);
            // 
            // txtOctet3
            // 
            this.txtOctet3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOctet3.Location = new System.Drawing.Point(67, 3);
            this.txtOctet3.Name = "txtOctet3";
            this.txtOctet3.Size = new System.Drawing.Size(27, 13);
            this.txtOctet3.TabIndex = 10;
            this.txtOctet3.Text = "0";
            this.txtOctet3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtOctet3.Leave += new System.EventHandler(this.txtOctet_Leave);
            this.txtOctet3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOctet_KeyPress);
            this.txtOctet3.Enter += new System.EventHandler(this.txtOctet_Enter);
            this.txtOctet3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.txtOctet_MouseUp);
            // 
            // txtOctet4
            // 
            this.txtOctet4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOctet4.Location = new System.Drawing.Point(100, 3);
            this.txtOctet4.Name = "txtOctet4";
            this.txtOctet4.Size = new System.Drawing.Size(27, 13);
            this.txtOctet4.TabIndex = 11;
            this.txtOctet4.Text = "0";
            this.txtOctet4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtOctet4.Leave += new System.EventHandler(this.txtOctet_Leave);
            this.txtOctet4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOctet_KeyPress);
            this.txtOctet4.Enter += new System.EventHandler(this.txtOctet_Enter);
            this.txtOctet4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.txtOctet_MouseUp);
            // 
            // IPTextBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.txtOctet4);
            this.Controls.Add(this.txtOctet3);
            this.Controls.Add(this.txtOctet2);
            this.Controls.Add(this.txtOctet1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "IPTextBox";
            this.Size = new System.Drawing.Size(131, 20);
            this.Resize += new System.EventHandler(this.IPTextBox_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOctet1;
        private System.Windows.Forms.TextBox txtOctet2;
        private System.Windows.Forms.TextBox txtOctet3;
        private System.Windows.Forms.TextBox txtOctet4;
    }