﻿using Integpg.JniorWebSocket;

namespace MultipleJniors
{
    class JniorConnection
    {
        public JniorWebSocket WebSocket { get; private set; }



        public JniorConnection(ConnectionProperties connectionPropterties)
        {
            WebSocket = new JniorWebSocket(connectionPropterties.IpAddress, connectionPropterties.Port);
            WebSocket.IsSecure = connectionPropterties.IsSecure;
        }

    }
}
